#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<string.h>
#include<signal.h>
char *buf;
FILE *fp;
pthread_t t1,t2;
sigset_t signals;
void *thread1(char *);
void *thread2(char *);
void reverse(char *);
int compareword(char *);
void main(int argc, char *args[])
  {
      int ret1, ret2;
      sigemptyset(&signals);
      sigaddset(&signals,SIGUSR2);
      if(argc!=3)
      {
      printf("entered incorrect number of arguments from command line\n");
      exit(-1);
      }
      buf=(char *)malloc(strlen(args[1]));
      if(buf==NULL){
        printf("memory error\n");
        return -1;
      }
      ret1=pthread_create(&t1,NULL,thread1,args[1]);
      if(ret1){
        printf("pthread_error\n");
        exit(-2);
      }
      ret2=pthread_create(&t2,NULL,thread2,args[2]);
      if(ret2){
        printf("pthread_error\n");
        exit(-3);
      }
      ret1=pthread_join(t1,NULL);
      if(ret1){
        printf("pthread_join error\n");
        exit(-5);
      }
      ret2=pthread_join(t2,NULL);
      if(ret2){
        printf("pthread_join error\n");
        exit(-6);
      }
      free(buf);

  }

void *thread1(char *ptr)
{ 
  printf("in thread1 string  = %s\n",ptr);
  strcpy(buf,ptr);raise(SIGUSR2);
  //pthread_kill(t2,SIGUSR2);
}
void *thread2( char *fptr)
    {
       int sig=SIGUSR2;
       sigwait(&signals,&sig);
       printf("file name is==%s\n",fptr);
       fp=fopen(fptr,"r");
       if(fp==NULL){
         printf("file open error\n");
         exit(-7);
       }
     char ch,b[100];
     int i=0,ret3;
     lseek(fp,0,SEEK_SET);
     while(1){
     ch=fgetc(fp);
     if(feof(fp))
         break;
     b[i]=ch;
     if(b[i]==' '){
	
         ret3=compareword(b);
       if(ret3==0){
         reverse(buf);
         
       }
       i=0;
     }
    else
     i++;
     }
     fclose(fp);
    }
int compareword(char *wrd)
{
	int j=0;
	for(j=0;j<strlen(buf);j++){
		if(buf[j]==wrd[j]){
			continue;
		}
		else{
			
			return 1;
		}
	}
 return 0;
}

void reverse(char *str)
{
  int i;
  i=strlen(str);
  while(i>=0){
    printf("%c",str[i]);
    i--;
  }
  printf("\n");
}
